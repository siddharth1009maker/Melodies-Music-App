// ENTRY POINT OF THE NODE APPLICATION

// imported express framework installed using npm i express
const express = require("express");
//console.log(typeof express); : returns function

// IMPORTED cors middleware from mpm
/*Cross-Origin Resource Sharing (CORS) is an HTTP-header based mechanism that allows a server to indicate any origins (domain, scheme, or port) other than its own from which a browser should permit loading of resources.
 * Here we used cors becoz. our react application is running on different port and nodejs application on other port so, single-origin policy rejects resourse shareing
 */
const cors = require("cors");

// IMPORTED dotenv package to get access  on .env file
const dotenv = require("dotenv");
//  configured dotenv - just like initialization
dotenv.config();

const app = express(); // app represent an application

// Adding Middlewares to every request and response
// to enable cross resourse sharing for every request,response
app.use(cors());
// to enable Json conversion for every request,response
app.use(express.json());

// Adding Middlewares for specific matching request
app.use("/", require("./routes/user")); // / root or Home
app.use("/", require("./routes/music"));
//console.log('App is ', typeof app); : returns function

// starting server to listen on port No 1234
const server = app.listen(1234, (err) => {
  // if some error come
  if (err) {
    //   console error
    console.log("Error is ", err);
  } else {
    // console server started at - port No
    console.log("Server Started.... ", server.address().port);
  }
});
