// User Route
// Whenever server get user related requests -> this route takes control

// requiring express package installed from npm
const express = require("express");
// extracting Router functionality from express
const routes = express.Router();

// Root Request - returns Welcome to Home page in Response
routes.get("/", (request, response) => {
  response.send("Welcome to the Home Page");
});

// Post request made by user to register
//if /register type request will be made this will take control
routes.post("/register", async (request, response) => {
  // extracting request body where user details are posted
  //automatically converts json to obj if required json
  let userObject = request.body;

  //requring useroperations which controls the functionalites related to user
  const userOperations = require("../db/services/useroperations");

  // passed userObject to register function using async Because Nodejs in Single threaded and Db operations are time consuming
  // await to stop flow till didn't got response
  // result is result object
  let result = await userOperations.register(userObject);

  // if valid result is arrived and it has truthy id then send Success in json form else Not added
  if (result && result._id) {
    response.status(200).json({ message: "Record added SuccessFully" });
  } else {
    response.status(200).json({ message: "Record Not added" });
  }
});

// Post request made by user to login
//if /login type request will be made this will take control
routes.post("/login", async (request, response) => {
  // extracting request body where user details are posted
  let userObject = request.body;

  //requring useroperations which controls the functionalites related to user
  const userOperations = require("../db/services/useroperations");

  // passed userObject to login function using async Because Nodejs in Single threaded and Db operations are time consuming
  // await to stop flow till didn't got response
  //returns result obj
  let result = await userOperations.login(userObject);

  // if result is truthy and have a id then message to Welcoms
  if (result && result._id) {
    response.status(200).json({ message: JSON.stringify(result) });
  } else {
    // else message invalid credentials
    response.status(200).json({ message: "Invalid" });
  }
});
module.exports = routes;
